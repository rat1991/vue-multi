<template>
  <div id="app">
    <img src="../../assets/logo.png">

    <input v-model.number="number" type="number" step="20">
    <p>{{ animatedNumber }}</p>
  </div>
</template>

<script>
export default {
  name: 'app',
  data() {
    return {
      number: '0',
      animatedNumber: '0'
    }
  },
  watch: {
    number(newVal, oldVal){
      let vm = this;
      function animate () {
        TWEEN.update() && requestAnimationFrame(animate)
      }
      new TWEEN.Tween({ tweeningNumber: oldVal })
        .easing(TWEEN.Easing.Quadratic.Out)
        .to({ tweeningNumber: newVal }, 1000)
        .onUpdate(function (e) {
          console.log(e)
          vm.animatedNumber = this.tweeningNumber.toFixed(0)
        })
        .start();
      animate()
    }
  }
}
</script>

<style lang="scss">
  @import "../../style/base.scss"
</style>

