<style lang="sass">
  @import "./common";
  // Reset and base
  @import "base/reset";
  @import "base/base";

  // Animation
  @import "animation/animation";

  // reuse
  @import "base/reuse";
  // lib-rem
  @import "base/lib-rem";
  // font-icon
  @import "icon/style.css";
</style>